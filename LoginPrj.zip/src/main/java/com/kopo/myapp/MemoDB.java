package com.kopo.myapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteConfig;

public class MemoDB {
	public boolean createDB() {
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db",
					config.toProperties());
			// use
			String query = "CREATE TABLE memos (idx INTEGER PRIMARY KEY AUTOINCREMENT"
					+ ", contents TEXT, userID TEXT, userIdx INT, created TEXT, updated TEXT)";
			// sqlite는 정수는 INTEGER, 실수는 REAL, 문자열 TEXT
			Statement statement = connection.createStatement();
			int result = statement.executeUpdate(query);
			
			statement.close();
			connection.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public String selectMemo(int userIdx) {
		String resultString = "";
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db", config.toProperties());
			
			// use
			String query = "SELECT * FROM memos where userIdx = ?;";
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, userIdx);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				int idx = resultSet.getInt("idx");
				String contents = resultSet.getString("contents");
				String created = resultSet.getString("created");
				String updated = resultSet.getString("updated");
				resultString = resultString + "<tr><td>" + idx + "</td><td>" + contents + "</td><td>" + created
						+ "</td><td>" + updated + "</td>" +
						"<td><a href='memoUpdate?idx=" + idx + "'>fix</a></td><td><a href='memoDelete?idx=" + idx + "'>delete</a></td></tr>";
			}
			preparedStatement.close();
			connection.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultString;
	}
	
	public boolean insertMemo(Memos memos) {
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db",
					config.toProperties());
			
			String query = "INSERT INTO memos (contents, userID, userIdx, created, updated)"
					+ " VALUES (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, memos.contents);
			preparedStatement.setString(2, memos.userID);
			preparedStatement.setInt(3, memos.userIdx);
			preparedStatement.setString(4, memos.created);
			preparedStatement.setString(5, memos.updated);
			int result = preparedStatement.executeUpdate();
			
			preparedStatement.close();
			connection.close();
			
			if (result < 1) {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public void updateMemo(int idx, String contents, String updated) {
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db", config.toProperties());

			String query = "UPDATE memos SET contents=?, updated=?, WHERE idx=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, contents);
			preparedStatement.setString(2, updated);
			preparedStatement.setInt(3, idx);
			int result = preparedStatement.executeUpdate();
			
			preparedStatement.close();
			connection.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteMemo(int idx) throws SQLException {
//		Memos resultData = new Memos();
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db", config.toProperties());
			
			// use
			String query = "DELETE FROM memos WHERE idx =?;";
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, idx);
			int resultSet = preparedStatement.executeUpdate();
			
			preparedStatement.close();
			connection.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	public String searchMemo(String contents) {
		String resultString = "";
		try {
			// open
			Class.forName("org.sqlite.JDBC");
			SQLiteConfig config = new SQLiteConfig();
			Connection connection = DriverManager.getConnection("jdbc:sqlite:/" + "c:/tomcat/login.db", config.toProperties());

			String query = "SELECT * FROM memos WHERE contents LIKE ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, "%" + contents + "%");
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				int idx = resultSet.getInt("idx");
				String rContents = resultSet.getString("contents");
				String created = resultSet.getString("created");
				String updated = resultSet.getString("updated");
				resultString = resultString + "<tr><td>" + idx + "</td><td>" + rContents + "</td><td>" + created
						+ "</td><td>" + updated + "</td>" +
						"<td><a href='memoUpdate?idx=" + idx + "'>fix</a></td><td><a href='memoDelete?idx=" + idx + "'>delete</a></td></tr>";
			}
			
			preparedStatement.close();
			connection.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultString;

	}
}
