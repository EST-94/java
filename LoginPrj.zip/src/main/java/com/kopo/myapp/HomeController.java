package com.kopo.myapp;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpServletRequest request, Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		HttpSession session = request.getSession();

		String formattedDate = "you haven't logged on yet.";
		
		try {
			String userID = (String)session.getAttribute("logname");
			if (userID != null) {
				formattedDate = "welcome, " + userID + ".";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String main(HttpServletRequest request, Locale locale, Model model) {
		HttpSession session = request.getSession();
		String outButton = "";
		
		try {
			String userID = (String)session.getAttribute("logname");
			if (userID != null) {
				outButton = "<a href='outsession'>logout</a>"
						+ "<a href='fixcurrent'>fix account info</a>"
						+ "<a href='memoMain'>memopad</a>";
			}
			if (userID == null) {
				outButton = "<a href='login'>login</a>";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		model.addAttribute("outButton", outButton);

		return "mainHT";
	}
	
	@RequestMapping(value = "/memoMain", method = RequestMethod.GET)
	public String memos(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession();
		String userID = (String)session.getAttribute("logname");
		String welcomeMsg = "hello, " + userID + ".";
		
		model.addAttribute("outString", welcomeMsg);
		return "mainMEMO";
	}
	
	@RequestMapping(value = "/memoInsert", method = RequestMethod.GET)
	public String memoinsert(Model model) {
		return "memoInsert";
	}
	
	@RequestMapping(value = "/memoInsert_act", method = RequestMethod.POST)
	public String memoinsert_act(HttpServletRequest request, Model model) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		HttpSession session = request.getSession();
		MemoDB memoDB = new MemoDB();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String now = sdf.format(Calendar.getInstance().getTime());
		
		String contents = request.getParameter("contents");
		int userIdx = (Integer) session.getAttribute("userIdx");

		
		Memos memo = new Memos(contents, userIdx, now, now);
		boolean isSuccess = memoDB.insertMemo(memo);
		if (isSuccess) {
			model.addAttribute("m1", "메모 입력 완료.");
		} else {
			model.addAttribute("m1", "메모 입력 실패.");
		}
		return "listMessage";
				
	}
	
	@RequestMapping(value = "/memoList", method = RequestMethod.GET)
	public String memolists(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession();
		MemoDB memo = new MemoDB();
		
		String htmlString = "";
		int userIdx = (Integer) session.getAttribute("userIdx");
		
		htmlString = memo.selectMemo(userIdx);
		
		model.addAttribute("outString", htmlString);
		
		return "memoList";
	}
	
	@RequestMapping(value = "/memoUpdate", method = RequestMethod.GET)
	public String updatememos(Model model
			, @RequestParam("idx") int idx) {
		MemoDB memoDB = new MemoDB();
		
		Memos selectMemo = memoDB.detailsMemo(idx);

		if (selectMemo != null) {
			model.addAttribute("contents", selectMemo.contents);
		}
		
		return "memoUpdate";
	}
	
	@RequestMapping(value = "/memoUpdate_act", method = RequestMethod.POST)
	public String memoupdate_act(HttpServletRequest request, Model model) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		MemoDB memoDb = new MemoDB();
		
		String sidx = request.getParameter("idx");
		int idx = Integer.parseInt(sidx);
		String contents = request.getParameter("contents");
		String now = sdf.format(Calendar.getInstance().getTime());
		
		memoDb.updateMemo(idx, contents, now);
				
		return "memoUpdate";
	}
	
	@RequestMapping(value = "/memoDelete", method = RequestMethod.GET)
	public String deletememos(Model model
			,@RequestParam("idx") int idx) {
		
		model.addAttribute("no", idx);

		return "memoDellCheck";
	}
	
	@RequestMapping(value = "/memoDel_act", method = RequestMethod.GET)
	public String deletememos_act(Model model
			,@RequestParam("idx") int idx) throws SQLException {
		
		MemoDB memoDB = new MemoDB();
		
		boolean isSuccess = memoDB.deleteMemo(idx);
		if (isSuccess) {
			model.addAttribute("m1", "메모 삭제 완료.");
		} else {
			model.addAttribute("m1", "메모 삭제 실패.");
		}
		return "listMessage";

	}
	
	@RequestMapping(value = "/fixcurrent", method = RequestMethod.GET)
	public String accountFix(HttpServletRequest request, Locale locale, Model model) {
		HttpSession session = request.getSession();
		UserDB db = new UserDB();
		
		String userID = (String)session.getAttribute("logname");
		
		People selectPeople = db.detailsIDData(userID);

		if (selectPeople != null) {
			model.addAttribute("idx", selectPeople.idx);
			model.addAttribute("pwd", selectPeople.pwd);
			model.addAttribute("name", selectPeople.name);
			model.addAttribute("birthday", selectPeople.birthday);
			model.addAttribute("address", selectPeople.address);
		}

		return "fixaccount";
	}
	
	@RequestMapping(value = "/fixcurrent_action", method = RequestMethod.POST)
	public String accountFixAct(HttpServletRequest request, Locale locale, Model model) {
		
		HttpSession session = request.getSession();
		String userID = (String)session.getAttribute("logname");

		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String nums = request.getParameter("idx");
		int idx = Integer.parseInt(nums);
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		String address = request.getParameter("address");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String now = sdf.format(Calendar.getInstance().getTime());
		
		UserDB db = new UserDB();
		
		db.updateCurrentData(idx, userID, pwd, name, birthday, address, now);
		
		model.addAttribute("m1", "<a href='home'>back to main</a>");

		return "listMessage";
	}
	
	@RequestMapping(value = "/outsession", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request, Locale locale, Model model) {
		HttpSession session = request.getSession();
		session.invalidate();

		return "redirect:/";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Locale locale, Model model) {
		return "login";
	}
	
	@RequestMapping(value = "/login_action", method = RequestMethod.POST)
	public String loginAction(HttpServletRequest request, Locale locale, Model model) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");

		UserDB userDB = new UserDB();
		boolean isSuccess = userDB.loginDB(id, pwd);
		if (isSuccess) {
			int userIdx = userDB.getIdx(id, pwd);
			HttpSession session = request.getSession();
			session.setAttribute("logname", id);
			session.setAttribute("logpw", pwd);
			session.setAttribute("isLogin", true);
			session.setAttribute("userIdx", userIdx);

			return "redirect:/";
		}
		return "redirect:/login";
	}	
	
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public String create(Locale locale, Model model) {
		UserDB userDB = new UserDB();
		MemoDB memoDB = new MemoDB();

		boolean isSuccess = userDB.createDB();
		memoDB.createDB();

		if (isSuccess) {
			model.addAttribute("m1", "테이블이 생성되었습니다.");
		} else {
			model.addAttribute("m1", "DB Error");
		}
		return "listmessage";
	}

	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public String insert(Locale locale, Model model) {
		return "listInsert";
	}
	
	@RequestMapping(value = "/insert_action", method = RequestMethod.POST)
	public String insertAction(HttpServletRequest request, Locale locale, Model model) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		String address = request.getParameter("address");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String now = sdf.format(Calendar.getInstance().getTime());
		People people = new People(id, pwd, name, birthday, address, now, now);
		
		UserDB userDB = new UserDB();
		boolean isSuccess = userDB.insertDB(people);
		if (isSuccess) {
			model.addAttribute("m1", "데이터가 입력되었습니다.");
		} else {
			model.addAttribute("m1", "아이디가 중복되었거나 DB에 이상이 있습니다.");
		}
		return "listMessage";
	}
	
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public String read(Locale locale, Model model) {
		UserDB db = new UserDB();
		String htmlString = db.selectData();
		
		model.addAttribute("list", htmlString);
		return "list";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String update(Locale locale, Model model
			, @RequestParam("idx") int idx) {
		UserDB db = new UserDB();
		
		People selectPeople = db.detailsData(idx);

		if (selectPeople != null) {
			model.addAttribute("idx", selectPeople.idx);
			model.addAttribute("id", selectPeople.id);
			model.addAttribute("pwd", selectPeople.pwd);
			model.addAttribute("name", selectPeople.name);
			model.addAttribute("birthday", selectPeople.birthday);
			model.addAttribute("address", selectPeople.address);
		}

		return "listUpdate_idx";
	}
	
	@RequestMapping(value = "/update_action", method = RequestMethod.GET)
	public String update_act(Locale locale, Model model
			, @RequestParam("idx") String sidx
			, @RequestParam("id") String id
			, @RequestParam("pwd") String pwd
			, @RequestParam("name") String name
			, @RequestParam("birthday") String birthday
			, @RequestParam("address") String address) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String now = sdf.format(Calendar.getInstance().getTime());
		
		UserDB db = new UserDB();
		int idx = Integer.parseInt(sidx);
		
		db.updateData(idx, id, pwd, name, birthday, address, now);
		
		return "listMessage";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(Locale locale, Model model
			, @RequestParam("idx") String idx) {
		int taNumber = Integer.parseInt(idx);
		UserDB db = new UserDB();
		String htmlString = "";
		String delString = "";
		
		People selectUnit = db.detailsData(taNumber);
		
		if (selectUnit != null) {
			htmlString = "<tr><td>" + selectUnit.idx
					+ "</td><td>" + selectUnit.name
					+ "</td><td>" + selectUnit.pwd
					+ "</td><td>" + selectUnit.name
					+ "</td><td>" + selectUnit.birthday
					+ "</td><td>" + selectUnit.address
					+ "</td><td>" + selectUnit.updated
					+ "</td><td>" + selectUnit.created
					+ "</td></tr>";
			delString = "<form action='delete_action' method = 'GET'>" + 
						"<input type='hidden' name='taIdx' value='" + selectUnit.idx + "'><br>"+
						"if you want to delete data which you searched, press 'delete' down below." +
						"<input type='submit' value='delete'>" + 
						"</form>";
		}
		else {
			htmlString = "\n\nno data found.";
		}
		
		model.addAttribute("list", htmlString);
		model.addAttribute("delbutton", delString);
		return "listDell";
	}
	
	@RequestMapping(value = "/deleteMain", method = RequestMethod.GET)
	public String deleteMain(Locale locale, Model model) {
		UserDB db = new UserDB();
		String htmlString = db.selectData();

		model.addAttribute("list", htmlString);
		return "listDell";
	}
	
	@RequestMapping(value = "/delete_action", method = RequestMethod.GET)
	public String delete_act(Locale locale, Model model
			, @RequestParam("taIdx") String taidx) {
		int taNumber = Integer.parseInt(taidx);
		UserDB db = new UserDB();
		String htmlString = "failed.";
		
		People selectUnit = db.detailsData(taNumber);
		
		if (selectUnit != null) {
			try {
				db.deleteData(taNumber);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			htmlString = "\n\nSuccess!";
		}
		else {
			htmlString = "\n\nfailed to load data.";
		}
		
		
		model.addAttribute("list", htmlString);
		return "listDell";
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String listsearchmain(Locale locale, Model model) {

		return "listSearch";
	}
	
	@RequestMapping(value = "/search_action", method = RequestMethod.GET)
	public String listsearchsend(Locale locale, Model model
			, @RequestParam("name") String name) {
		UserDB db = new UserDB();
		String htmlString = db.searchData(name);
		
		model.addAttribute("list", htmlString);
		return "listSearch";
	}
}
