package com.kopo.myapp;

public class Memos {
	int idx;
	String contents;
	String userID;
	int userIdx;
	String created;
	String updated;
	
	Memos() {
		
	}
	
	Memos(String contents, String userID, int userIdx, String created, String updated) {
		this.contents = contents;
		this.userID = userID;
		this.userIdx = userIdx;
		this.created = created;
		this.updated = updated;
	}
	
	Memos(int idx, String contents, String userID, int userIdx, String created, String updated) {
		this.idx = idx;
		this.contents = contents;
		this.userID = userID;
		this.userIdx = userIdx;
		this.created = created;
		this.updated = updated;
	}
}