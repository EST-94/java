package com.kopo.myapp;

public class Student2 {
	int idx;
	String name;
	int middleScore;
	int finalScore;
	
	Student2() {
		
	}
	
	Student2(String name, int middleScore, int finalScore){
		this.name = name;
		this.middleScore = middleScore;
		this.finalScore = finalScore;
	}
	
}
