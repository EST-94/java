package com.kopo.myapp;

public class Student {
	int idx;
	String name;
	int score;
	
	Student() {
		
	}
	
	Student(String name, int score){
		this.name = name;
		this.score = score;
	}
	
}
